<meta property="og:type" content="article" />
<meta property="og:title" content="{{ $post->title }}" />
<meta property="og:description" content="{{ collect($post->ingredients['sentences'])->shuffle()->random() }}" />
<meta property="og:url" content="http://www.cnn.com/2014/08/11/travel/sagano-bamboo-forest/" />
<meta property="og:site_name" content="CNN.com" />
<meta property="article:published_time" content="2014-08-12T00:01:56+00:00" />
<meta property="article:author" content="CNN Karla Cripps" />