<?xml version='1.0' encoding='UTF-8'?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <?php $__currentLoopData = \App\Post::whereNotNull('content')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <url>
        <loc><?php echo e($site_url); ?><?php echo e($post->slug); ?>.html</loc>
        <lastmod><?php echo e($post->published_at->toISOString()); ?></lastmod>
    </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>
<?php /**PATH /Users/buchin/Repos/suki/app/Commands/Shuriken/Export/Sitemap/sitemap.blade.php ENDPATH**/ ?>