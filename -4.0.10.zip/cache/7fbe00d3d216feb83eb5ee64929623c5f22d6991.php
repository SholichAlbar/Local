<?php
    $sentences = collect($post->ingredients['sentences']);
    $images = collect($post->ingredients['images']);
?>
<article>
    <p><strong><?php echo e($post['title']); ?></strong>. <?php echo e($sentences->take(15)->shuffle()->take(2)->implode(' ')); ?></p>

    <p>
        <?php $image = collect($images)->shuffle()->pop(); ?>
        <?php if($image): ?>
        <figure>
            <img src="<?php echo e($image['image']); ?>" alt="<?php echo e($image['title']); ?>" style="width: 100%; padding: 5px; background-color: grey;"  onerror="this.onerror=null;this.src='<?php echo e($image['thumbnail']); ?>';">
            <figcaption><?php echo e($image['title']); ?></figcaption>
        </figure>
        <?php endif; ?>
        <?php echo e($sentences->shuffle()->take(3)->implode(' ')); ?>

    </p>

    <h3><?php echo e($sentences->shuffle()->pop()); ?></h3>
    <p><?php echo e($sentences->shuffle()->pop()); ?> <?php echo e($sentences->shuffle()->take(3)->implode(' ')); ?></p>
</article>

<section>
<?php $__currentLoopData = collect($images)->shuffle()->take(9); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <aside>
        <a href="<?php echo e($image['image']); ?>" target="_blank"><img alt="<?php echo e($image['title']); ?>" src="<?php echo e($image['thumbnail']); ?>" width="100%" onerror="this.onerror=null;this.src='<?php echo e($image['image']); ?>';"></a>
        <p><?php echo e($sentences->shuffle()->pop()); ?></p>
    </aside>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php /**PATH /Users/buchin/Repos/suki/app/Commands/Sushi/Duckduckgo/Image/content.blade.php ENDPATH**/ ?>