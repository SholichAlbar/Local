<?php
    $sentences = collect($post->ingredients['sentences']);
    $images = collect($post->ingredients['images']);
?>
<p><strong><?php echo e($post['title']); ?></strong>. <?php echo e($sentences->take(15)->shuffle()->take(2)->implode(' ')); ?></p>

<p>
    <?php $img = collect($images)->shuffle()->pop(); ?>
    <?php if($img): ?>
    <figure>
        <img src="<?php echo e($img['image']); ?>" alt="<?php echo e($img['title']); ?>" style="width: 100%; padding: 5px; background-color: grey;">
        <figcaption><?php echo e($img['title']); ?></figcaption>
    </figure>
    <?php endif; ?>
    <?php echo e($sentences->shuffle()->take(3)->implode(' ')); ?>

</p>

<h3><?php echo e($sentences->shuffle()->pop()); ?></h3>
<p><?php echo e($sentences->shuffle()->pop()); ?></p>

<?php $chunks = collect($images)->shuffle()->take(9)->chunk(3) ?>

<?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="display: grid;grid-template-columns: auto auto auto; background: #eee; ">
        <?php $__currentLoopData = $chunked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="padding: 1em;">
                <a href="<?php echo e($image['image']); ?>"><img src="<?php echo e($image['image']); ?>" onerror="this.onerror=null;this.src='<?php echo e($image['thumbnail']); ?>';" style="width:100%;margin-top: 8px;vertical-align: middle;"></a>
                <p><?php echo e($image['title']); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<p><?php echo e($sentences->shuffle()->take(3)->implode(' ')); ?></p>
<?php /**PATH /Users/buchin/Repos/suki/app/Commands/Duckduckgo/Image/content.blade.php ENDPATH**/ ?>