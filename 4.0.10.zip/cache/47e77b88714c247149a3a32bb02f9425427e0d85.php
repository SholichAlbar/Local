<?php $__env->startSection('title'); ?>
    <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<?php echo $post->json_ld; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
    <?php echo e(collect($post->ingredients['sentences'])->random()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $post->content; ?>


<section>
    <article>
        <p>
            <?php if($post->previous): ?>
                <a href="<?php echo e($post->previous->slug); ?>.html"><i>&larr; <?php echo e($post->previous->title); ?></i></a>
            <?php endif; ?>

            <?php if($post->parent): ?>
                <a href="<?php echo e($post->parent->slug); ?>.html"><i><?php echo e($post->parent->title); ?></i></a>
            <?php endif; ?>

            <?php if($post->next): ?>
                <a href="<?php echo e($post->next->slug); ?>.html"><i><?php echo e($post->next->title); ?> &rarr;</i></a>
            <?php endif; ?>
        </p>
    </article>
</section>

<section>
    <header><h3>Related Posts</h3></header>
    <?php $__currentLoopData = $random_posts->split(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked_posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <aside>
            <ul>
                <?php $__currentLoopData = $chunked_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e($post->slug); ?>.html"><?php echo e($post->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </aside>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/suki/app/Commands/Sushi/Export/Html/post.blade.php ENDPATH**/ ?>