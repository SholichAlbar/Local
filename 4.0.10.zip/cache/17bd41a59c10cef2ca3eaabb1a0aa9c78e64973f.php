---
title: "<?php echo e($post->title); ?>"
description: "<?php echo e(collect($post->ingredients['sentences'])->shuffle()->random()); ?>"
date: "<?php echo e($post->published_at->format('Y-m-d')); ?>"
categories:
  - "<?php echo e($post->category); ?>"
images: 
  - "<?php echo e(collect($post->ingredients['images'])->shuffle()->random()['image']); ?>"
featuredImage: "<?php echo e(collect($post->ingredients['images'])->shuffle()->random()['image']); ?>"
featured_image: "<?php echo e(collect($post->ingredients['images'])->shuffle()->random()['image']); ?>"
image: "<?php echo e(collect($post->ingredients['images'])->shuffle()->random()['image']); ?>"
---

<?php echo $post->content; ?><?php /**PATH /Users/buchin/Repos/suki/templates/export/hugo/post.blade.php ENDPATH**/ ?>